const constants = {
  TAB_OPTION: {
    POSTS: "Posts",
    ALBUMS: "Albums",
    TODOS: "Todos"
  },
  NUM_GRID_COLUMNS: 3
};

export default constants;
