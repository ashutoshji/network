const size = {
  large: 22,
  medium: 18,
  small: 16,
  verySmall: 14
};

export default size;
