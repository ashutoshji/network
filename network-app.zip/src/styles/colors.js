const colors = {
  white: "#FFF",
  black: "#000",
  darkestBlue: "#13293D",
  darkBlue: "#16324F",
  blue: "#1481BA",
  lightBlue: "#0CAADC",
  lightestBlue: "#11B5E4",
  cream: "#F7F7F2",
  tan: "#E4E6C3"
};

export default colors;
